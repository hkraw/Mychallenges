#!/bin/sh
./ynetd -p 10111 "./server"
